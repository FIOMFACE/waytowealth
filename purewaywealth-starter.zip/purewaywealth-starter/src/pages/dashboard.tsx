import { useEffect, useState } from 'react'
type Weights = { health:number; finance:number; peace:number }

export default function Dashboard(){
  const [w, setW] = useState<Weights>({health:40, finance:35, peace:25})
  useEffect(()=>{
    const s = localStorage.getItem('pww_weights')
    if (s) setW(JSON.parse(s))
  },[])

  const cards = [
    {pillar:'Health', title:'Sleep Reset – Day 1'},
    {pillar:'Finance', title:'Budget in 30 Minutes'},
    {pillar:'Peace', title:'5-Min Breathing Audio'},
    {pillar:'Health', title:'Office Stretch (10 min)'},
    {pillar:'Finance', title:'Debt Snowball Starter'},
    {pillar:'Peace', title:'Evening Unplug Ritual'},
  ]

  const order = Object.entries(w).sort((a,b)=>b[1]-a[1]).map(([k])=>k)
  const priority = (p:string)=> order.indexOf(p.toLowerCase())
  const blended = [...cards].sort((a,b)=> priority(a.pillar)-priority(b.pillar))

  return (
    <main className="max-w-5xl mx-auto p-6">
      <h1 className="text-3xl font-bold">Your Mix Today</h1>
      <p className="text-gray-600 mt-2">Health {w.health}% • Finance {w.finance}% • Peace {w.peace}%</p>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
        {blended.map((c, i)=> (
          <div key={i} className="rounded-2xl border p-4">
            <p className="text-xs text-gray-500">{c.pillar}</p>
            <h3 className="text-lg font-semibold">{c.title}</h3>
            <button className="mt-3 rounded-lg bg-blue-600 text-white px-3 py-2 text-sm">Start</button>
          </div>
        ))}
      </div>
    </main>
  )
}
