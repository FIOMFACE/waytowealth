import Link from 'next/link'

const demo = [
  {slug:'health-sleep-reset', title:'Sleep Reset (7 Days)', price:0, pillar:'Health'},
  {slug:'finance-budget-101', title:'Budget 101', price:499, pillar:'Finance'},
  {slug:'peace-mindfulness-basics', title:'Mindfulness Basics', price:499, pillar:'Peace'},
]

export default function Courses(){
  return (
    <main className="max-w-5xl mx-auto p-6">
      <h1 className="text-3xl font-bold">Courses</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
        {demo.map(c => (
          <div key={c.slug} className="rounded-2xl border p-5">
            <p className="text-xs text-gray-500">{c.pillar}</p>
            <h3 className="text-xl font-semibold">{c.title}</h3>
            <p className="mt-2">{c.price===0 ? 'Free' : `₹${c.price}`}</p>
            <div className="mt-4 flex gap-2">
              <Link href={`/courses/${c.slug}`} className="rounded-lg bg-blue-600 text-white px-3 py-2 text-sm">View</Link>
              <Link href={`/checkout/${c.slug}`} className="rounded-lg border px-3 py-2 text-sm">Buy</Link>
            </div>
          </div>
        ))}
      </div>
    </main>
  )
}
