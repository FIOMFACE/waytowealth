import { useRouter } from 'next/router'

export default function CoursePage(){
  const { query } = useRouter()
  const { slug } = query
  return (
    <main className="max-w-3xl mx-auto p-6">
      <p className="text-sm text-gray-500">Course</p>
      <h1 className="text-3xl font-bold">{slug}</h1>
      <p className="mt-4 text-gray-700">This is a placeholder course page. Replace with real content and access control.</p>
    </main>
  )
}
