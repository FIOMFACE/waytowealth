import { useRouter } from 'next/router'

export default function Checkout(){
  const { productId } = useRouter().query
  return (
    <main className="max-w-xl mx-auto p-6">
      <h1 className="text-2xl font-bold">Checkout</h1>
      <p className="mt-2">You are buying: <b>{productId as string}</b></p>
      <p className="mt-4 text-sm text-gray-600">Integrate Razorpay by creating an order server-side and capturing success via webhook.</p>
    </main>
  )
}
