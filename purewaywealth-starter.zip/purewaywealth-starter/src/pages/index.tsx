import Link from 'next/link'
export default function Home() {
  return (
    <main className="min-h-screen bg-white">
      <section className="mx-auto max-w-5xl px-6 py-16 text-center">
        <h1 className="text-4xl md:text-6xl font-bold">Define Wealth <span className="text-blue-600">Your</span> Way</h1>
        <p className="mt-4 text-lg text-gray-600">Health • Finance • Peace of Mind. Take a 60-second quiz and get a plan built for you.</p>
        <div className="mt-8 flex justify-center gap-4">
          <Link href="/quiz" className="rounded-xl px-6 py-3 bg-blue-600 text-white hover:opacity-90">Start Your Quiz</Link>
          <Link href="/courses" className="rounded-xl px-6 py-3 border border-gray-300 hover:bg-gray-50">Explore Courses</Link>
        </div>
      </section>
      <section className="mx-auto max-w-5xl px-6 pb-24 grid grid-cols-1 md:grid-cols-3 gap-6">
        {['Health','Finance','Peace of Mind'].map((c)=>(
          <div key={c} className="rounded-2xl shadow p-6 text-left">
            <h3 className="text-xl font-semibold">{c}</h3>
            <p className="mt-2 text-gray-600">Bite-sized lessons, practical tasks, real progress.</p>
          </div>
        ))}
      </section>
      <footer className="border-t py-10 text-center text-sm text-gray-500">© {new Date().getFullYear()} PureWayWealth</footer>
    </main>
  )
}
