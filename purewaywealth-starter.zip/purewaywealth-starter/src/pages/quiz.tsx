import { useState } from 'react'
import { supabase } from '@/lib/supabaseClient'
import { useRouter } from 'next/router'
import questionnaire from '@/questionnaire.json'

type Weights = { health: number; finance: number; peace: number }

export default function Quiz() {
  const [health, setHealth] = useState(34)
  const [finance, setFinance] = useState(33)
  const [peace, setPeace] = useState(33)
  const [email, setEmail] = useState('')
  const router = useRouter()

  const total = health + finance + peace

  const submit = async () => {
    if (total !== 100) {
      alert('Please ensure the total equals 100.')
      return
    }
    await supabase.from('users_public').insert({ email }).onConflict('email').ignore()
    await supabase.from('profiles').upsert({
      user_email: email,
      h_weight: health,
      f_weight: finance,
      p_weight: peace,
    })

    const weights: Weights = { health, finance, peace }
    localStorage.setItem('pww_weights', JSON.stringify(weights))
    router.push('/dashboard')
  }

  return (
    <main className="max-w-2xl mx-auto p-6">
      <h1 className="text-3xl font-bold">Personalize Your Plan</h1>
      <p className="text-gray-600 mt-2">Distribute 100 points across the 3 pillars.</p>
      <div className="mt-6 space-y-4">
        <Slider label="Health" value={health} setValue={setHealth} />
        <Slider label="Finance" value={finance} setValue={setFinance} />
        <Slider label="Peace of Mind" value={peace} setValue={setPeace} />
      </div>
      <p className="mt-2 text-sm text-gray-500">Total: {total}</p>
      <div className="mt-6">
        <input
          type="email"
          placeholder="Email (for saving your profile)"
          className="w-full rounded-xl border px-4 py-3"
          value={email}
          onChange={(e)=>setEmail(e.target.value)}
        />
      </div>
      <button onClick={submit} className="mt-6 rounded-xl bg-blue-600 text-white px-6 py-3 hover:opacity-90">Save & See Dashboard</button>

      <section className="mt-10">
        <h2 className="text-xl font-semibold">A few quick questions</h2>
        <ul className="list-disc pl-6 text-gray-700 mt-2">
          {questionnaire.likert.map((q:any)=> <li key={q.id}>{q.text}</li>)}
        </ul>
      </section>
    </main>
  )
}

function Slider({label, value, setValue}:{label:string; value:number; setValue:(n:number)=>void}){
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700">{label}: {value}</label>
      <input
        type="range"
        min={0}
        max={100}
        value={value}
        onChange={(e)=>setValue(parseInt(e.target.value))}
        className="w-full"
      />
    </div>
  )
}
